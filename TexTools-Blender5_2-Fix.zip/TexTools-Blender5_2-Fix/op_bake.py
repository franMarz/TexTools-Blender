import bpy
import os
import time

from . import utilities_ui
from . import utilities_uv
from . import settings
from . import utilities_bake as ub


modes={
	'normal_tangent':			ub.BakeMode('',						type='NORMAL', 		color=(0.5, 0.5, 1, 1), use_project=True),
	'normal_object': 			ub.BakeMode('',						type='NORMAL', 		color=(0.5, 0.5, 1, 1), normal_space='OBJECT'),
	'bevel_mask':				ub.BakeMode('bake_bevel_mask',		type='EMIT', 		color=(0, 0, 0, 1), 	params=["bake_bevel_samples","bake_bevel_size"]),
	'normal_tangent_bevel':		ub.BakeMode('bake_bevel_normal',	type='NORMAL', 		color=(0.5, 0.5, 1, 1),	params=["bake_bevel_samples","bake_bevel_size"]),
	'normal_object_bevel':		ub.BakeMode('bake_bevel_normal',	type='NORMAL', 		color=(0.5, 0.5, 1, 1),	normal_space='OBJECT', params=["bake_bevel_samples","bake_bevel_size"]),
	'thickness':				ub.BakeMode('bake_thickness',		type='EMIT', 		color=(0, 0, 0, 1), 	params=["bake_samples","bake_thickness_distance","bake_thickness_contrast","bake_thickness_local"]),
	'cavity': 					ub.BakeMode('bake_cavity',			type='EMIT', 		setVColor=ub.setup_vertex_color_dirty),
	'paint_base': 				ub.BakeMode('bake_paint_base',		type='EMIT'),
	'dust': 					ub.BakeMode('bake_dust',			type='EMIT', 		setVColor=ub.setup_vertex_color_dirty),
	'ao':						ub.BakeMode('',						type='AO', 			params=["bake_samples"], engine='CYCLES'),
	'position':					ub.BakeMode('bake_position',		type='EMIT'),
	'curvature':				ub.BakeMode('',						type='NORMAL',		use_project=True, 	params=["bake_curvature_size"], composite="curvature"),
	'wireframe':				ub.BakeMode('bake_wireframe',		type='EMIT', 		color=(0, 0, 0, 1), params=["bake_wireframe_size"]),
	'id_element':				ub.BakeMode('bake_vertex_color',	type='EMIT', 		setVColor=ub.setup_vertex_color_id_element),
	'id_material':				ub.BakeMode('bake_vertex_color',	type='EMIT', 		setVColor=ub.setup_vertex_color_id_material),
	'selection':				ub.BakeMode('bake_vertex_color',	type='EMIT', 		color=(0, 0, 0, 1), setVColor=ub.setup_vertex_color_selection),
	'diffuse':					ub.BakeMode('',						type='DIFFUSE'),
	'base_color':				ub.BakeMode('',						type='EMIT',							relink = {'needed':True, 'b':ub.chs['ech'], 'n':0}),
	'sss_strength':				ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['ssch']}),
	'sss_color':				ub.BakeMode('',						type='EMIT',							relink = {'needed':True, 'b':ub.chs['ech'], 'n':ub.chs['scch']}),
	'metallic':					ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['mch']}),
	'specular':					ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['sch']}),
	'specular_tint':			ub.BakeMode('',						type='EMIT',		color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['ech'], 'n':ub.chs['stch']}),
	'roughness':				ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1)),
	'glossiness':				ub.BakeMode('',						type='ROUGHNESS',	color=(1, 1, 1, 1), invert=True),
	'anisotropic':				ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['ach']}),
	'anisotropic_rotation':		ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['arch']}),
	'sheen':					ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['shch']}),
	'sheen_tint':				ub.BakeMode('',						type='EMIT',		color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['ech'], 'n':ub.chs['shtch']}),
	'clearcoat':				ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['cch']}),
	'clearcoat_roughness':		ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['crch']}),
	'transmission':				ub.BakeMode('',						type='TRANSMISSION'),
	'transmission_roughness':	ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['trch']}),
	'emission':					ub.BakeMode('',						type='EMIT',		color=(0, 0, 0, 1)),
	'environment':				ub.BakeMode('',						type='ENVIRONMENT'),
	'uv':						ub.BakeMode('',						type='UV'),
	'shadow':					ub.BakeMode('',						type='SHADOW',		params=["bake_samples"]),
	'combined':					ub.BakeMode('',						type='COMBINED',	params=["bake_samples"])
}

if settings.bversion >= 2.91:
	modes['emission_strength']= ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1),	relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['esch']})
	modes['alpha']= 			ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1), relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['alch']})
else:
	modes['alpha']= 			ub.BakeMode('',						type='ROUGHNESS',	color=(0, 0, 0, 1), relink = {'needed':True, 'b':ub.chs['rch'], 'n':ub.chs['esch']})


class op(bpy.types.Operator):
	bl_idname = "uv.textools_bake"
	bl_label = "Bake"
	bl_description = "Bake selected objects"

	@classmethod
	def poll(cls, context):
		if len(settings.sets) == 0:
			settings.bake_error = ""
			return False
		
		bake_mode = utilities_ui.get_bake_mode()
		if bake_mode not in modes:
			settings.bake_error = ""
			return False
		
		if bake_mode in {'ao','normal_tangent','normal_object','curvature','environment','uv','shadow'}:
			settings.bake_error = ""
			return True

		if bake_mode == 'combined':
			if (not bpy.context.scene.render.bake.use_pass_direct) and (not bpy.context.scene.render.bake.use_pass_indirect) and (not bpy.context.scene.render.bake.use_pass_emit):
				settings.bake_error = "Lighting or Emit needed"
				return False
			settings.bake_error = ""
			return True
		
		if modes[bake_mode].setVColor or not modes[bake_mode].material:
			def is_bakeable(obj):
				if len(obj.data.materials) <= 0 or not any(obj.data.materials):
					settings.bake_error = "Materials needed"
					return False
				for slot in obj.material_slots:
					if slot.material is not None:
						if slot.material.use_nodes == False:
							settings.bake_error = "Nodal materials needed"
							return False
						bsdf_node = next((n for n in slot.material.node_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
						if not bsdf_node:
							bool_alpha_ignore = bpy.context.preferences.addons[__package__].preferences.bool_alpha_ignore
							bool_clean_transmission = bpy.context.preferences.addons[__package__].preferences.bool_clean_transmission
							builtin_modes_material = {'diffuse','emission','roughness','glossiness','transmission'}
							if modes[bake_mode].relink['needed'] or (bool_clean_transmission and bake_mode == 'transmission') or (bool_alpha_ignore and bake_mode not in builtin_modes_material):
								settings.bake_error = "BSDF nodes needed"
								return False
				settings.bake_error = ""
				return True

			def is_vc_ready(obj):
				settings.bake_error = ""
				return True

			for bset in settings.sets:
				target_objs = bset.objects_low if len(bset.objects_high) + len(bset.objects_float) == 0 else (bset.objects_high + bset.objects_float)
				for obj in target_objs:
					if not modes[bake_mode].material and not is_bakeable(obj):
						return False

		settings.bake_error = ""
		return True

	def execute(self, context):
		startTime = time.monotonic()
		preferences = bpy.context.preferences.addons[__package__].preferences
		circular_report = [False, ]
		color_report = [False, ]

		if preferences.bool_clean_transmission:
			modes['transmission'] = ub.BakeMode('', type='ROUGHNESS', color=(0, 0, 0, 1), relink={'needed':True, 'b':7, 'n':15})
		else:
			modes['transmission'] = ub.BakeMode('', type='TRANSMISSION')

		bake_mode = utilities_ui.get_bake_mode()
		if bake_mode not in modes:
			self.report({'ERROR_INVALID_INPUT'}, f"Unknown mode '{bake_mode}'")
			return {'CANCELLED'}

		selected_objects = [obj for obj in bpy.context.selected_objects]
		active_object = bpy.context.view_layer.objects.active
		pre_selection_mode = active_object.mode if active_object else None
		ub.store_bake_settings()

		if preferences.bake_device != 'DEFAULT':
			bpy.context.scene.cycles.device = preferences.bake_device
		bpy.context.scene.render.engine = modes[bake_mode].engine

		if settings.bversion < 3:
			bpy.context.scene.cycles.use_progressive_refine = False
		if settings.bversion >= 2.92:
			bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
		if settings.bversion >= 3:
			bpy.context.scene.cycles.use_denoising = False

		bake(
			self=self, 
			mode=bake_mode,
			size=bpy.context.scene.texToolsSettings.size, 
			bake_force=bpy.context.scene.texToolsSettings.bake_force,
			sampling_scale=int(bpy.context.scene.texToolsSettings.bake_sampling),
			samples=bpy.context.scene.texToolsSettings.bake_samples,
			cage_extrusion=bpy.context.scene.texToolsSettings.bake_cage_extrusion,
			ray_distance=bpy.context.scene.texToolsSettings.bake_ray_distance,
			circular_report=circular_report,
			color_report=color_report,
			selected=selected_objects,
			active=active_object,
			pre_selection_mode=pre_selection_mode
		)

		elapsed = round(time.monotonic() - startTime, 2)
		if circular_report[0]:
			msg = "Possible Circular Dependency warning. "
			if color_report[0]:
				msg += color_report[0] + ". "
			self.report({'WARNING'}, f"{msg}Baking finished in {elapsed}s.")
		else:
			if color_report[0]:
				self.report({'WARNING'}, f"{color_report[0]}. Baking finished in {elapsed}s.")
			else:
				self.report({'INFO'}, f"Baking finished in {elapsed}s.")

		return {'FINISHED'}


def bake(self, mode, size, bake_force, sampling_scale, samples, cage_extrusion, ray_distance, circular_report, color_report, selected, active, pre_selection_mode):
	sets = settings.sets

	for bset in sets:
		if len(bset.objects_low) == 0:
			self.report({'ERROR_INVALID_INPUT'}, f"No low poly object for '{bset.name}'")
			return {'CANCELLED'}
		for obj in bset.objects_low:
			if not obj.data.uv_layers:
				self.report({'ERROR_INVALID_INPUT'}, f"No UV map for '{obj.name}'")
				return {'CANCELLED'}

	if bpy.context.view_layer.objects.active is not None and bpy.context.object.mode != 'OBJECT':
		bpy.ops.object.mode_set(mode='OBJECT')

	bool_emission_strength_ignore = bpy.context.preferences.addons[__package__].preferences.bool_emission_ignore
	bool_alpha_ignore = bpy.context.preferences.addons[__package__].preferences.bool_alpha_ignore
	render_width = sampling_scale * size[0]
	render_height = sampling_scale * size[1]

	material_loaded = get_material(mode)
	if material_loaded is not None:
		setup_material_loaded(mode, material_loaded)

	if mode == 'id_material':
		if len(ub.allMaterials) > 0:
			for i, mtl in enumerate(ub.allMaterials):
				try:
					mtl.name
				except:
					ub.allMaterials[i] = bpy.data.materials.get(ub.allMaterialsNames[i])
		else:
			ub.allMaterials = [mtl for mtl in bpy.data.materials if (mtl is not None and mtl.users != 0)]
			ub.allMaterialsNames = [mtl.name for mtl in ub.allMaterials]

	if mode == 'id_element':
		ub.elementsCount = 0

	previous_materials = {}
	copied_materials = {}
	tiles = []

	for bset in sets:
		for obj in (bset.objects_low + bset.objects_high + bset.objects_float):
			if obj not in previous_materials:
				previous_materials[obj] = [mtl.name if mtl else None for mtl in obj.data.materials]

	def use_copied_mtls(obj):
		for i, mtl in enumerate(obj.data.materials):
			if mtl is not None:
				if mtl not in copied_materials:
					mat_copied = mtl.copy()
					obj.data.materials[i] = mat_copied
					copied_materials[mtl.name] = mat_copied.name
				else:
					obj.data.materials[i] = copied_materials[mtl.name]

	def use_material_loaded(obj):
		mat = bpy.data.materials[material_loaded]
		if len(obj.data.materials) > 0:
			for i in range(len(obj.data.materials)):
				obj.data.materials[i] = mat
		else:
			obj.data.materials.append(mat)

	for bset in settings.sets:
		if (len(bset.objects_high) + len(bset.objects_float)) == 0:
			tiles.append(utilities_uv.get_UDIM_tiles(bset.objects_low))
			for obj in bset.objects_low:
				if material_loaded is None:
					use_copied_mtls(obj)
				else:
					use_material_loaded(obj)
		else:
			tiles.append(utilities_uv.get_UDIM_tiles(bset.objects_high + bset.objects_float))
			if material_loaded is None:
				for obj in (bset.objects_low + bset.objects_high + bset.objects_float):
					use_copied_mtls(obj)
			else:
				for obj in bset.objects_low:
					use_copied_mtls(obj)
				for obj in (bset.objects_high + bset.objects_float):
					use_material_loaded(obj)

	relinkedMaterials = []
	EmissionIgnoredMaterials = []
	AlphaIgnoredMaterials = []
	bakeReadyMaterials = []
	stored_images = []

	try:
		for s, bset in enumerate(sets):
			name_texture = f"{bset.name}_{mode}"
			if bake_force == "Single":
				name_texture = f"{sets[0].name}_{mode}"

			is_clear = (not bake_force == "Single") or (bake_force == "Single" and s == 0)

			if is_clear:
				bakeReadyMaterials = []
				loaded = material_loaded is not None
				image, previous_image = setup_image(color_report, mode, name_texture, render_width, render_height, tiles[s], material_load=loaded)
				imagecopy = image.copy() if image == previous_image else None

				stored_images.append([image.name, previous_image.name if previous_image else None, imagecopy.name if imagecopy else None, name_texture])

			def assign_tune_materials(obj, setup_bake_nodes=False):
				if material_loaded is not None:
					if mode == 'id_material':
						for mtlname in previous_materials[obj]:
							if mtlname is not None and bpy.data.materials[mtlname] not in ub.allMaterials:
								ub.allMaterials.append(bpy.data.materials[mtlname])
								ub.allMaterialsNames.append(mtlname)
					if modes[mode].setVColor:
						ub.assign_vertex_color(obj)
						if mode == 'id_material':
							modes[mode].setVColor(obj, previous_materials)
						else:
							modes[mode].setVColor(obj)
				elif modes[mode].relink['needed']:
					for slot in obj.material_slots:
						if slot.material and slot.material not in relinkedMaterials:
							relink_nodes(mode, slot.material)
							relinkedMaterials.append(slot.material)
					if setup_bake_nodes:
						setup_image_bake_node(obj, bakeReadyMaterials, stored_images[-1][0], stored_images[-1][1], stored_images[-1][2])

			if (len(bset.objects_high) + len(bset.objects_float)) == 0:
				for obj in bset.objects_low:
					if len(obj.material_slots) == 0 or not all(obj.data.materials):
						if "TT_bake_node" not in bpy.data.materials:
							bpy.data.materials.new(name="TT_bake_node")
						if len(obj.material_slots) == 0:
							obj.data.materials.append(bpy.data.materials["TT_bake_node"])
						else:
							for slot in obj.material_slots:
								if not slot.material:
									slot.material = bpy.data.materials["TT_bake_node"]
					assign_tune_materials(obj, setup_bake_nodes=True)
			else:
				for obj in bset.objects_low:
					if len(obj.material_slots) == 0 or not all(obj.data.materials):
						if "TT_bake_node" not in bpy.data.materials:
							bpy.data.materials.new(name="TT_bake_node")
						if len(obj.material_slots) == 0:
							obj.data.materials.append(bpy.data.materials["TT_bake_node"])
						else:
							for slot in obj.material_slots:
								if not slot.material:
									slot.material = bpy.data.materials["TT_bake_node"]
					setup_image_bake_node(obj, bakeReadyMaterials, stored_images[-1][0], stored_images[-1][1], stored_images[-1][2])
				for obj in (bset.objects_high + bset.objects_float):
					assign_tune_materials(obj)

			for obj_cage in bset.objects_cage:
				obj_cage.hide_render = True

			for i in range(len(bset.objects_low)):
				obj_low = bset.objects_low[i]
				obj_cage = bset.objects_cage[i] if i < len(bset.objects_cage) else None
				obj_low.hide_render = False

				bpy.ops.object.select_all(action='DESELECT')
				obj_low.select_set(state=True)
				bpy.context.view_layer.objects.active = obj_low

				if is_clear and i == 0 and modes[mode].invert:
					bpy.ops.image.invert(invert_r=True, invert_g=True, invert_b=True, invert_a=False)

				for obj_high in bset.objects_high:
					obj_high.select_set(state=True)

				cycles_bake(mode, bpy.context.scene.texToolsSettings.padding, sampling_scale, samples, cage_extrusion, ray_distance, len(bset.objects_high) > 0, obj_cage)

				if len(bset.objects_float) > 0:
					bpy.ops.object.select_all(action='DESELECT')
					for obj_high in bset.objects_float:
						obj_high.select_set(state=True)
					obj_low.select_set(state=True)

					cycles_bake(mode, 0, sampling_scale, samples, cage_extrusion, ray_distance, True, obj_cage)

			for obj_cage in bset.objects_cage:
				obj_cage.hide_render = False

			if (not bake_force == "Single") or (bake_force == "Single" and s == len(sets) - 1):
				if modes[mode].invert:
					bpy.ops.image.invert(invert_r=True, invert_g=True, invert_b=True, invert_a=False)
				if render_width != size[0] or render_height != size[1]:
					bpy.data.images[stored_images[-1][0]].scale(size[0], size[1])
				if modes[mode].composite:
					apply_composite(stored_images[-1][0], modes[mode].composite, bpy.context.scene.texToolsSettings.bake_curvature_size)

	finally:
		for obj in previous_materials:
			if len(previous_materials[obj]) == 0:
				if len(obj.material_slots) > 0:
					obj.active_material_index = 0
					for _ in range(len(obj.material_slots)):
						bpy.ops.object.material_slot_remove({'object': obj})
			else:
				for i, mtlname in enumerate(previous_materials[obj]):
					obj.data.materials[i] = bpy.data.materials.get(mtlname) if mtlname else None

		for mtl in copied_materials.values():
			mat = bpy.data.materials.get(mtl)
			if mat:
				bpy.data.materials.remove(mat, do_unlink=True)

		if "TT_bake_node" in bpy.data.materials:
			bpy.data.materials.remove(bpy.data.materials["TT_bake_node"], do_unlink=True)
		if material_loaded is not None and material_loaded in bpy.data.materials:
			bpy.data.materials.remove(bpy.data.materials[material_loaded], do_unlink=True)

		for images in stored_images:
			img_name, prev_name, copy_name = images[0], images[1], images[2]
			if prev_name and prev_name in bpy.data.images and bpy.data.images[img_name] != bpy.data.images[prev_name]:
				for material in bpy.data.materials:
					if material.use_nodes:
						for node in material.node_tree.nodes:
							if node.bl_idname == 'ShaderNodeTexImage' and node.image == bpy.data.images[prev_name]:
								node.image = bpy.data.images[img_name]

			if copy_name and copy_name in bpy.data.images:
				bpy.data.images.remove(bpy.data.images[copy_name], do_unlink=True)
			elif prev_name and prev_name in bpy.data.images:
				bpy.data.images.remove(bpy.data.images[prev_name], do_unlink=True)

			if img_name in bpy.data.images:
				bpy.data.images[img_name].name = images[3]

		ub.restore_bake_settings()
		bpy.ops.object.select_all(action='DESELECT')
		for obj in selected:
			obj.select_set(state=True)
		bpy.ops.object.mode_set(mode='EDIT')
		bpy.ops.object.mode_set(mode='OBJECT')
		if active:
			bpy.context.view_layer.objects.active = active
			bpy.ops.object.mode_set(mode=pre_selection_mode)


def apply_composite(image_name, scene_name, size):
	image = bpy.data.images[image_name]
	previous_scene = bpy.context.window.scene
	preWorldPropertiesNodesBool = previous_scene.world.use_nodes if previous_scene.world else False

	scene = bpy.data.scenes.get(scene_name)
	if not scene:
		path = os.path.join(os.path.dirname(__file__), "resources/compositing.blend", "Scene")
		bpy.ops.wm.append(filename=scene_name, directory=path, link=False, autoselect=False)
		scene = bpy.data.scenes.get(scene_name)

	if scene:
		bpy.context.window.scene = scene
		if scene.world:
			scene.world.use_nodes = preWorldPropertiesNodesBool

		if "Image" in scene.node_tree.nodes:
			scene.node_tree.nodes["Image"].image = image
		if "Offset" in scene.node_tree.nodes:
			scene.node_tree.nodes["Offset"].outputs[0].default_value = size

		bpy.ops.render.render(use_viewport=False)

		image_viewer_node = get_last_item("Viewer Node", bpy.data.images)
		image_render_result = get_last_item("Render Result", bpy.data.images)

		image.pixels = image_viewer_node.pixels[:]
		image.update()

		if image_viewer_node:
			bpy.data.images.remove(image_viewer_node)
		if image_render_result:
			bpy.data.images.remove(image_render_result)

		bpy.context.window.scene = previous_scene
		bpy.data.scenes.remove(scene)


def get_last_item(key_name, collection):
	keys = [item.name for item in collection if key_name in item.name]
	if keys:
		return collection[keys[-1]]
	return None


def setup_image(color_report, mode, name, width, height, tiles, material_load=False):
	preferences = bpy.context.preferences.addons[__package__].preferences
	bake_back_color = bpy.context.scene.texToolsSettings.bake_back_color if preferences.bool_bake_back_color == 'CUSTOM' else modes[mode].color

	def set_color_space(color_report, image):
		image.alpha_mode = 'NONE'
		try:
			image.colorspace_settings.name = bpy.context.scene.texToolsSettings.bake_color_space
		except:
			color_report[0] = "Color Space type not available"

	def resize(image):
		if image.size[0] != width or image.size[1] != height:
			image.scale(width, height)

	def set_image_as_background(image):
		for area in bpy.context.screen.areas:
			if area.ui_type == 'UV':
				area.spaces[0].image = image

	def image_create():
		is_float_32 = preferences.bake_32bit_float == '32'
		if tiles and settings.bversion >= 3.2:
			image = bpy.data.images.new(name, width=width, height=height, alpha=True, float_buffer=is_float_32, tiled=True)
			set_image_as_background(image)
			set_color_space(color_report, image)
			image.tiles.get(1001).generated_color = bake_back_color
			for tile in tiles:
				bpy.ops.image.tile_add(number=tile, count=1, label="", fill=True, width=width, height=height, float=is_float_32, alpha=True, color=bake_back_color)
			image.tiles.active_index = 0
		else:
			image = bpy.data.images.new(name, width=2, height=2, alpha=True, float_buffer=is_float_32, tiled=False)
			set_image_as_background(image)
			set_color_space(color_report, image)
			image.pixels = [pv for _ in range(4) for pv in bake_back_color]
			resize(image)
		return image

	if name in bpy.data.images:
		previous_image = bpy.data.images[name]
		if previous_image.source == 'FILE' and not os.path.isfile(bpy.path.abspath(previous_image.filepath)):
			image = image_create()
			return (image, None) if material_load else (image, previous_image)
		else:
			set_image_as_background(previous_image)
			set_color_space(color_report, previous_image)
			if settings.bversion < 3.2 or not tiles:
				previous_image.scale(2, 2)
				previous_image.pixels = [pv for _ in range(4) for pv in bake_back_color]
				resize(previous_image)
			return (previous_image, None) if material_load else (previous_image, previous_image)
	else:
		image = image_create()
		return image, None


def setup_image_bake_node(obj, bakeReadyMaterials, image_name, previous_image_name, imagecopy_name):
	image = bpy.data.images.get(image_name)
	previous_image = bpy.data.images.get(previous_image_name) if previous_image_name else None
	imagecopy = bpy.data.images.get(imagecopy_name) if imagecopy_name else None

	def avoid_circular(tree, img):
		for node in tree.nodes:
			if node.bl_idname == 'ShaderNodeTexImage' and node.image == img:
				node.image = imagecopy

	def assign_node(tree):
		node = tree.nodes.get("TexTools_bake")
		if not node:
			node = tree.nodes.new("ShaderNodeTexImage")
			node.name = "TexTools_bake"
		node.select = True
		node.image = image
		tree.nodes.active = node

	for slot in obj.material_slots:
		if slot.material and slot.material.name not in bakeReadyMaterials:
			if not slot.material.use_nodes:
				slot.material.use_nodes = True
			if image == previous_image and imagecopy:
				avoid_circular(slot.material.node_tree, image)
			assign_node(slot.material.node_tree)
			bakeReadyMaterials.append(slot.material.name)


def relink_nodes(mode, material):
	if not material.use_nodes:
		material.use_nodes = True
	tree = material.node_tree
	bsdf_node = next((n for n in tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
	if not bsdf_node:
		return

	b, n = modes[mode].relink['b'], modes[mode].relink['n']
	base_node = base_socket = None
	if len(bsdf_node.inputs[b].links) != 0:
		base_node = bsdf_node.inputs[b].links[0].from_node
		base_socket = bsdf_node.inputs[b].links[0].from_socket.name

	if len(bsdf_node.inputs[n].links) != 0:
		new_node = bsdf_node.inputs[n].links[0].from_node
		new_node_socket = bsdf_node.inputs[n].links[0].from_socket.name
		if new_node != base_node or base_socket != new_node_socket:
			bsdf_node.inputs[b].default_value = bsdf_node.inputs[n].default_value
			tree.links.new(new_node.outputs[new_node_socket], bsdf_node.inputs[b])
	else:
		if base_node:
			tree.links.remove(bsdf_node.inputs[b].links[0])
		bsdf_node.inputs[b].default_value = bsdf_node.inputs[n].default_value


def setup_material_loaded(mode, name):
	mat = bpy.data.materials.get(name)
	if not mat:
		return
	if mode == 'wireframe' and "Value" in mat.node_tree.nodes:
		mat.node_tree.nodes["Value"].outputs[0].default_value = bpy.context.scene.texToolsSettings.bake_wireframe_size
	elif "bevel" in mode and "Bevel" in mat.node_tree.nodes:
		mat.node_tree.nodes["Bevel"].inputs[0].default_value = bpy.context.scene.texToolsSettings.bake_bevel_size
		mat.node_tree.nodes["Bevel"].samples = bpy.context.scene.texToolsSettings.bake_bevel_samples


def get_material(mode):
	if modes[mode].material == "":
		return None
	name = modes[mode].material
	path = os.path.join(os.path.dirname(__file__), "resources/materials.blend", "Material")
	if "bevel" in mode or "thickness" in mode:
		path = os.path.join(os.path.dirname(__file__), "resources/materials_2.80.blend", "Material")
	if bpy.data.materials.get(name) is None:
		bpy.ops.wm.append(filename=name, directory=path, link=False, autoselect=False)
	return name


def cycles_bake(mode, padding, sampling_scale, samples, cage_extrusion, ray_distance, is_multi, obj_cage):
	if modes[mode].engine in {'CYCLES', 'BLENDER_EEVEE'}:
		if modes[mode].normal_space == 'OBJECT':
			bpy.context.scene.render.bake.normal_r = 'POS_X'
			bpy.context.scene.render.bake.normal_g = 'POS_Z'
			bpy.context.scene.render.bake.normal_b = 'NEG_Y'
		elif modes[mode].normal_space == 'TANGENT':
			bpy.context.scene.render.bake.normal_r = 'POS_X'
			bpy.context.scene.render.bake.normal_b = 'POS_Z'
			swizzle_y = bpy.context.preferences.addons[__package__].preferences.swizzle_y_coordinate
			bpy.context.scene.render.bake.normal_g = 'NEG_Y' if swizzle_y == 'Y-' else 'POS_Y'

		bpy.context.scene.cycles.samples = samples
		if modes[mode].type in {'EMIT', 'DIFFUSE', 'ROUGHNESS', 'TRANSMISSION', 'ENVIRONMENT', 'UV'} and mode != 'thickness':
			bpy.context.scene.cycles.samples = 1

		bpy.context.scene.render.bake.margin = padding * sampling_scale
		if modes[mode].type == 'DIFFUSE':
			bpy.context.scene.render.bake.use_pass_direct = False
			bpy.context.scene.render.bake.use_pass_indirect = False
			bpy.context.scene.render.bake.use_pass_color = True

		if obj_cage is None:
			bpy.ops.object.bake(
				type=modes[mode].type, 
				use_clear=False, 
				use_selected_to_active=is_multi, 
				cage_extrusion=cage_extrusion, 
				max_ray_distance=ray_distance, 
				normal_space=modes[mode].normal_space
			)
		else:
			bpy.ops.object.bake(
				type=modes[mode].type, 
				use_clear=False, 
				use_selected_to_active=is_multi, 
				cage_extrusion=cage_extrusion, 
				max_ray_distance=ray_distance, 
				normal_space=modes[mode].normal_space, 
				use_cage=True, 
				cage_object=obj_cage.name
			)


bpy.utils.register_class(op)