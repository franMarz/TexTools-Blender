import bpy
import bmesh

from . import utilities_meshtex


class op(bpy.types.Operator):
	bl_idname = "uv.textools_meshtex_wrap"
	bl_label = "Wrap Mesh Texture"
	bl_description = "Swap UV to XYZ coordinates"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		if bpy.context.scene.texToolsSettings.meshtexture_wrap < 1:
			return False
		if (not bpy.context.active_object) or bpy.context.active_object.mode != 'OBJECT':
			return False
		if len(bpy.context.selected_objects) > 0:
			if utilities_meshtex.find_uv_mesh(bpy.context.selected_objects):
				if len(utilities_meshtex.find_texture_meshes(bpy.context.selected_objects)) > 0:
					return True
		return False


	def execute(self, context):
		wrap_meshtex(self)
		return {'FINISHED'}


def wrap_meshtex(self):
	obj_uv = utilities_meshtex.find_uv_mesh(bpy.context.selected_objects)
	if not obj_uv:
		self.report({'ERROR_INVALID_INPUT'}, "No UV mesh found")
		return

	obj_textures = utilities_meshtex.find_texture_meshes(bpy.context.selected_objects)
	if len(obj_textures) == 0:
		self.report({'ERROR_INVALID_INPUT'}, "No meshes found for mesh textures")
		return

	for obj in obj_textures:
		for modifier in obj.modifiers:
			if modifier.type == 'SURFACE_DEFORM':
				obj.modifiers.remove(modifier)
				break

		modifier_deform = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
		modifier_deform.target = obj_uv

		obj.select_set(state=True)
		bpy.context.view_layer.objects.active = obj
		bpy.ops.object.surfacedeform_bind(modifier="SurfaceDeform")

	bpy.context.scene.texToolsSettings.meshtexture_wrap = 0


bpy.utils.register_class(op)