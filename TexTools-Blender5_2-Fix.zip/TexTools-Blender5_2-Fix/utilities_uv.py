import bpy
import bmesh
import math
import mathutils

from mathutils import Vector
from . import settings
from . import utilities_ui

precision = 5
multi_object_loop_stop = False


def multi_object_loop(func, *args, need_results=False, **kwargs):
	selected_obs = [ob for ob in bpy.context.selected_objects if ob.type == 'MESH']

	if len(selected_obs) == 1:
		preactiv_name = bpy.context.view_layer.objects.active.name
		bpy.context.view_layer.objects.active = selected_obs[0]
		if not need_results:
			func(*args, **kwargs)
			if bpy.data.objects.get(preactiv_name):
				bpy.context.view_layer.objects.active = bpy.data.objects[preactiv_name]
		else:
			result = func(*args, **kwargs)
			if bpy.data.objects.get(preactiv_name):
				bpy.context.view_layer.objects.active = bpy.data.objects[preactiv_name]
			return [result]
	else:
		global multi_object_loop_stop
		multi_object_loop_stop = False
		premode = bpy.context.active_object.mode
		preactiv_name = bpy.context.view_layer.objects.active.name

		bpy.ops.object.mode_set(mode='EDIT', toggle=False)
		unique_selected_obs = [ob for ob in bpy.context.objects_in_mode_unique_data if ob.type == 'MESH' and ob.select_get()]
		bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
		bpy.ops.object.select_all(action='DESELECT')

		results = [] if need_results else None
		for ob in unique_selected_obs:
			if multi_object_loop_stop: break
			bpy.context.view_layer.objects.active = ob
			bpy.ops.object.mode_set(mode='EDIT', toggle=False)
			if need_results:
				results.append(func(*args, **kwargs))
			else:
				func(*args, **kwargs)
			if "ob_num" in kwargs: kwargs["ob_num"] += 1
			bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
			bpy.ops.object.select_all(action='DESELECT')

		for ob in selected_obs:
			ob.select_set(True)

		bpy.context.view_layer.objects.active = bpy.data.objects[preactiv_name]
		bpy.ops.object.mode_set(mode=premode)
		if need_results: return results


def selection_store(bm=None, uv_layers=None, return_selected_UV_faces=False, return_selected_faces_edges=False, return_selected_faces_loops=False):
	if bm is None:
		bm = bmesh.from_edit_mesh(bpy.context.active_object.data)
		uv_layers = bm.loops.layers.uv.verify()

	settings.use_uv_sync = bpy.context.scene.tool_settings.use_uv_select_sync
	settings.selection_uv_mode = bpy.context.scene.tool_settings.uv_select_mode

	contextViewUV = utilities_ui.GetContextViewUV()
	if contextViewUV:
		settings.selection_uv_pivot = contextViewUV['area'].spaces[0].pivot_point
		settings.selection_uv_pivot_pos = contextViewUV['area'].spaces[0].cursor_location.copy()

	settings.selection_vert_indexies.clear()
	settings.selection_edge_indexies.clear()
	settings.selection_face_indexies.clear()
	settings.seam_edges.clear()
	settings.selection_mode = tuple(bpy.context.scene.tool_settings.mesh_select_mode)

	if settings.selection_mode[0]:
		for vert in bm.verts:
			if vert.select: settings.selection_vert_indexies.add(vert.index)
	if settings.selection_mode[1]:
		for edge in bm.edges:
			if edge.select: settings.selection_edge_indexies.add(edge.index)

	settings.selection_uv_loops.clear()
	selected_faces = set() if return_selected_UV_faces else None
	selected_faces_loops = {} if (return_selected_faces_edges or return_selected_faces_loops) else None

	for face in bm.faces:
		if face.select: settings.selection_face_indexies.add(face.index)
		n_selected_loops = 0
		face_selected_loops = [] if (return_selected_faces_edges or return_selected_faces_loops) else None
		
		for loop in face.loops:
			if loop.edge.seam: settings.seam_edges.add(loop.edge)
			if loop.uv_select_vert:
				n_selected_loops += 1
				settings.selection_uv_loops.add((face.index, loop.vert.index))
				if face_selected_loops is not None: face_selected_loops.append(loop)
		
		if return_selected_UV_faces and n_selected_loops == len(face.loops) and face.select:
			selected_faces.add(face)
		elif return_selected_faces_edges and n_selected_loops == 2 and face.select:
			selected_faces_loops.update({face: face_selected_loops})
		elif return_selected_faces_loops and n_selected_loops > 0 and face.select:
			selected_faces_loops.update({face: face_selected_loops})

	if return_selected_UV_faces: return selected_faces
	elif return_selected_faces_edges or return_selected_faces_loops: return selected_faces_loops


def selection_restore(bm=None, uv_layers=None, restore_seams=False):
	mode = bpy.context.object.mode
	if mode != 'EDIT': bpy.ops.object.mode_set(mode='EDIT')
	if bm is None:
		bm = bmesh.from_edit_mesh(bpy.context.active_object.data)
		uv_layers = bm.loops.layers.uv.verify()

	bpy.context.scene.tool_settings.use_uv_select_sync = settings.use_uv_sync
	bpy.context.scene.tool_settings.uv_select_mode = settings.selection_uv_mode

	contextViewUV = utilities_ui.GetContextViewUV()
	if contextViewUV:
		contextViewUV['area'].spaces[0].pivot_point = settings.selection_uv_pivot
		if settings.bversion >= 3.2:
			with bpy.context.temp_override(**contextViewUV):
				bpy.ops.uv.cursor_set(location=settings.selection_uv_pivot_pos)
		else:
			bpy.ops.uv.cursor_set(contextViewUV, location=settings.selection_uv_pivot_pos)

	if restore_seams:
		bpy.ops.mesh.select_all(action='SELECT')
		bpy.ops.mesh.mark_seam(clear=True)
		for edge in settings.seam_edges: edge.seam = True

	bpy.ops.mesh.select_all(action='DESELECT')
	bpy.context.scene.tool_settings.mesh_select_mode = settings.selection_mode
	
	if settings.selection_mode[0]:
		bm.verts.ensure_lookup_table()
		for index in settings.selection_vert_indexies:
			if index < len(bm.verts): bm.verts[index].select = True
	if settings.selection_mode[1]:
		bm.edges.ensure_lookup_table()
		for index in settings.selection_edge_indexies:
			if index < len(bm.edges): bm.edges[index].select = True
	bm.faces.ensure_lookup_table()
	for index in settings.selection_face_indexies:
		if index < len(bm.faces): bm.faces[index].select = True

	if contextViewUV:
		if settings.bversion >= 3.2:
			with bpy.context.temp_override(**contextViewUV):
				bpy.ops.uv.select_all(action='DESELECT')
		else:
			bpy.ops.uv.select_all(contextViewUV, action='DESELECT')
	else:
		for face in bm.faces:
			for loop in face.loops: loop.uv_select_vert = False

	for uv_set in settings.selection_uv_loops:
		for loop in bm.faces[uv_set[0]].loops:
			if loop.vert.index == uv_set[1]:
				loop.uv_select_vert = True
				break

	if settings.selection_uv_mode != "VERTEX":
		bpy.ops.uv.select_mode(type='VERTEX')
	bpy.context.scene.tool_settings.uv_select_mode = settings.selection_uv_mode

	bpy.context.view_layer.update()
	bpy.ops.object.mode_set(mode=mode)


def get_UDIM_tile_coords(obj):
	udim_tile, column, row = 1001, 0, 0
	if bpy.context.scene.texToolsSettings.UDIMs_source == 'OBJECT':
		if obj and obj.type == 'MESH' and obj.data.uv_layers:
			for slot in obj.material_slots:
				if slot.material and slot.material.node_tree:
					for node in slot.material.node_tree.nodes:
						if node.type == 'TEX_IMAGE' and node.image and node.image.source == 'TILED':
							udim_tile = node.image.tiles.active.number
							break
					break
	else:
		image = bpy.context.space_data.image
		if image: udim_tile = image.tiles.active.number

	if udim_tile != 1001:
		column = int(str(udim_tile - 1)[-1])
		if udim_tile > 1010: row = int(str(udim_tile - 1001)[0:-1])
	return udim_tile, column, row


def get_UDIM_tiles(objs):
	tiles = set()
	for obj in objs:
		for slot in obj.material_slots:
			if slot.material and slot.material.node_tree:
				for node in slot.material.node_tree.nodes:
					if node.type == 'TEX_IMAGE' and node.image and node.image.source == 'TILED':
						tiles.update({tile.number for tile in node.image.tiles})
	return tiles


def move_island(island, dx, dy):
	me = bpy.context.active_object.data
	bm = bmesh.from_edit_mesh(me)
	uv_layer = bm.loops.layers.uv.verify()
	for face in island:
		for loop in face.loops:
			loop[uv_layer].uv[0] += dx
			loop[uv_layer].uv[1] += dy
	bmesh.update_edit_mesh(me)


def rotate_island(island, uv_layer=None, angle=0, center_x=0, center_y=0):
	if uv_layer is None:
		me = bpy.context.active_object.data
		bm = bmesh.from_edit_mesh(me)
		uv_layer = bm.loops.layers.uv.verify()	

	for face in island:
		for loop in face.loops:
			x, y = loop[uv_layer].uv
			xt, yt = x - center_x, y - center_y
			xr = (xt * math.cos(angle)) - (yt * math.sin(angle))
			yr = (xt * math.sin(angle)) + (yt * math.cos(angle))
			loop[uv_layer].uv.x = xr + center_x
			loop[uv_layer].uv.y = yr + center_y


def scale_island(island, uv_layer, scale_x, scale_y, pivot=None):
	if not pivot: pivot = get_BBOX(island, None, uv_layer)['center']
	for face in island:
		for loop in face.loops:
			x, y = loop[uv_layer].uv               
			xt, yt = x - pivot.x, y - pivot.y
			loop[uv_layer].uv.x = (xt * scale_x) + pivot.x
			loop[uv_layer].uv.y = (yt * scale_y) + pivot.y


def set_selected_faces(faces, bm, uv_layers):
	for face in faces:
		for loop in face.loops: loop.uv_select_vert = True


def get_selected_uvs(bm, uv_layers):
	return {loop[uv_layers] for face in bm.faces if face.select for loop in face.loops if loop.uv_select_vert}


def get_selected_uv_verts(bm, uv_layers, selected=None):
	if selected is None:
		return {loop.vert for face in bm.faces if face.select for loop in face.loops if loop.uv_select_vert}
	return {loop.vert for loop in selected}


def get_selected_uv_edges(bm, uv_layers, selected=None):
	verts = get_selected_uv_verts(bm, uv_layers, selected)
	return {edge for edge in bm.edges if edge.verts[0] in verts and edge.verts[1] in verts}


def get_selected_uv_faces(bm, uv_layers):
	return [face for face in bm.faces if all([loop.uv_select_vert for loop in face.loops]) and face.select]


def get_vert_to_uv(bm, uv_layers):
	vert_to_uv = {}
	for face in bm.faces:
		for loop in face.loops:
			vert_to_uv.setdefault(loop.vert, []).append(loop[uv_layers])
	return vert_to_uv


def get_uv_to_vert(bm, uv_layers):
	return {loop[uv_layers]: loop.vert for face in bm.faces for loop in face.loops}


def getSelectionBBox(bm=None, uv_layers=None):
	if bm is None:
		bm = bmesh.from_edit_mesh(bpy.context.active_object.data)
		uv_layers = bm.loops.layers.uv.verify()
	
	xmin, xmax, ymin, ymax = math.inf, -math.inf, math.inf, -math.inf
	select = False
	for face in bm.faces:
		if face.select:
			for loop in face.loops:
				if loop.uv_select_vert:
					select = True
					x, y = loop[uv_layers].uv
					if xmin > x: xmin = x
					if xmax < x: xmax = x
					if ymin > y: ymin = y
					if ymax < y: ymax = y
					
	if not select: return {}
	return {
		'min': Vector((xmin, ymin)), 'max': Vector((xmax, ymax)),
		'width': xmax - xmin, 'height': ymax - ymin,
		'center': Vector(((xmax + xmin) * 0.5, (ymax + ymin) * 0.5)),
		'area': (xmax - xmin) * (ymax - ymin),
		'minLength': min(xmax - xmin, ymax - ymin)
	}


def get_BBOX(group, bm, uv_layers, are_loops=False):
	xmin, xmax, ymin, ymax = math.inf, -math.inf, math.inf, -math.inf
	target = [loop for face in group for loop in face.loops] if not are_loops else group
	for loop in target:
		x, y = loop[uv_layers].uv
		if xmin > x: xmin = x
		if xmax < x: xmax = x
		if ymin > y: ymin = y
		if ymax < y: ymax = y

	return {
		'min': Vector((xmin, ymin)), 'max': Vector((xmax, ymax)),
		'width': xmax - xmin, 'height': ymax - ymin,
		'center': Vector(((xmax + xmin) * 0.5, (ymax + ymin) * 0.5)),
		'area': (xmax - xmin) * (ymax - ymin),
		'minLength': min(xmax - xmin, ymax - ymin)
	}


def get_island_BBOX(island, bm, uv_layers):
	boundsMin, boundsMax = Vector((99999999.0, 99999999.0)), Vector((-99999999.0, -99999999.0))
	for face in island:
		for loop in face.loops:
			uv = loop[uv_layers].uv
			boundsMin.x, boundsMin.y = min(boundsMin.x, uv.x), min(boundsMin.y, uv.y)
			boundsMax.x, boundsMax.y = max(boundsMax.x, uv.x), max(boundsMax.y, uv.y)
	return {'min': boundsMin, 'max': boundsMax, 'center': (boundsMax + boundsMin) / 2}


def get_BBOX_multi(all_ob_bounds):
	boundsMin, boundsMax = Vector((99999999.0, 99999999.0)), Vector((-99999999.0, -99999999.0))
	for ob_bounds in all_ob_bounds:
		if len(ob_bounds) > 1:
			boundsMin.x, boundsMin.y = min(boundsMin.x, ob_bounds['min'].x), min(boundsMin.y, ob_bounds['min'].y)
			boundsMax.x, boundsMax.y = max(boundsMax.x, ob_bounds['max'].x), max(boundsMax.y, ob_bounds['max'].y)

	return {
		'min': boundsMin, 'max': boundsMax,
		'width': (boundsMax - boundsMin).x, 'height': (boundsMax - boundsMin).y,
		'center': (boundsMax + boundsMin) / 2,
		'area': (boundsMax - boundsMin).x * (boundsMax - boundsMin).y,
		'minLength': min((boundsMax - boundsMin).x, (boundsMax - boundsMin).y)
	}


def get_center(group, bm, uv_layers, are_loops=False):
	n, total = 0, Vector((0.0, 0.0))
	target = [loop for face in group for loop in face.loops] if not are_loops else group
	for loop in target:
		total += loop[uv_layers].uv
		n += 1
	return total / n if n > 0 else total


def getFacesIslands(bm, uv_layers, faces, islands, disordered_island_faces):
	for face in faces:
		if face in disordered_island_faces:
			bpy.ops.uv.select_all(action='DESELECT')
			face.loops[0].uv_select_vert = True
			bpy.ops.uv.select_linked()
			islandFaces = {f for f in disordered_island_faces if f.loops[0].uv_select_vert}
			disordered_island_faces.difference_update(islandFaces)
			islands.append(islandFaces)
			if not disordered_island_faces: break


def getAllIslands(bm, uv_layers):
	faces = {f for f in bm.faces if f.select}
	if not faces: return []
	islands, faces_unparsed = [], faces.copy()
	getFacesIslands(bm, uv_layers, faces, islands, faces_unparsed)
	return islands


def getSelectionIslands(bm, uv_layers, extend_selection_to_islands=False, selected_faces=None, need_faces_selected=True, restore_selected=True):
	if selected_faces is None:
		selected_faces = {f for f in bm.faces if all([l.uv_select_vert for l in f.loops]) and f.select} if need_faces_selected else {f for f in bm.faces if any([l.uv_select_vert for l in f.loops]) and f.select}
	if not selected_faces: return []

	if extend_selection_to_islands:
		bpy.ops.uv.select_linked()
		disordered_island_faces = {f for f in bm.faces if f.loops[0].uv_select_vert and f.select}
	else:
		disordered_island_faces = selected_faces.copy()

	islands = []
	getFacesIslands(bm, uv_layers, selected_faces, islands, disordered_island_faces)
	if restore_selected:
		bpy.ops.uv.select_all(action='DESELECT')
		set_selected_faces(selected_faces, bm, uv_layers)
	return islands


def getSelectedUnselectedIslands(bm, uv_layers, selected_faces=None, target_faces=None, restore_selected=False):
	if selected_faces is None: return [], []
	selected_islands = []
	bpy.ops.uv.select_linked()
	disordered_islands_selected = {f for f in bm.faces if f.loops[0].uv_select_vert and f.select}
	getFacesIslands(bm, uv_layers, selected_faces, selected_islands, disordered_islands_selected)

	if target_faces is None: return selected_islands, []
	target_islands = []
	target_faces.difference_update(disordered_islands_selected)
	bpy.ops.uv.select_all(action='DESELECT')
	for f in target_faces: f.loops[0].uv_select_vert = True
	bpy.ops.uv.select_linked()
	disordered_islands_targets = {f for f in bm.faces if f.loops[0].uv_select_vert and f.select}
	getFacesIslands(bm, uv_layers, target_faces, target_islands, disordered_islands_targets)

	if restore_selected:
		bpy.ops.uv.select_all(action='DESELECT')
		set_selected_faces(selected_faces, bm, uv_layers)
	return selected_islands, target_islands


def getSelectionFacesIslands(bm, uv_layers, selected_faces_loops):
	bpy.ops.uv.select_linked()
	disordered_island_faces = {f for f in bm.faces if f.loops[0].uv_select_vert and f.select}
	selected_faces_islands, to_remove = {}, set()

	for face in selected_faces_loops.keys():
		if face not in disordered_island_faces: to_remove.add(face)
		else:
			bpy.ops.uv.select_all(action='DESELECT')
			face.loops[0].uv_select_vert = True
			bpy.ops.uv.select_linked()
			face_island = {f for f in disordered_island_faces if f.loops[0].uv_select_vert}
			disordered_island_faces.difference_update(face_island)
			selected_faces_islands.update({face: face_island})

	for face in to_remove: selected_faces_loops.pop(face)
	return selected_faces_islands, selected_faces_loops


def find_min_rotate_angle(angle):
	angle = math.degrees(angle)
	x = math.fmod(angle, 90)
	if angle > 45:
		y = 90 - x
		angle = -y if y < x else x
	elif angle < -45:
		y = -90 - x
		angle = -y if y > x else x
	return math.radians(angle)


def alignMinimalBounds(bm, uv_layers, selected_faces):
	uv_coords = [l[uv_layers].uv for f in selected_faces for l in f.loops]
	align_angle = find_min_rotate_angle(mathutils.geometry.box_fit_2d(uv_coords))
	if abs(align_angle) > 0.001:
		rot_matrix = mathutils.Matrix(((math.cos(align_angle), math.sin(align_angle)), (-math.sin(align_angle), math.cos(align_angle))))
		for f in selected_faces:
			for l in f.loops: l[uv_layers].uv = l[uv_layers].uv @ rot_matrix


def alignMinimalBounds_multi():
	steps, angle = 8, 45
	all_ob_bounds = multi_object_loop(getSelectionBBox, need_results=True)
	if not any(all_ob_bounds): return {'CANCELLED'}

	bboxPrevious = get_BBOX_multi(all_ob_bounds)
	for _ in range(steps):
		bpy.ops.transform.rotate(value=(angle * math.pi / 180), orient_axis='Z', constraint_axis=(False, False, False), use_proportional_edit=False)
		bbox = get_BBOX_multi(multi_object_loop(getSelectionBBox, need_results=True))

		if bbox['minLength'] < bboxPrevious['minLength']:
			bboxPrevious = bbox
		else:
			bpy.ops.transform.rotate(value=(-angle * 2 * math.pi / 180), orient_axis='Z', constraint_axis=(False, False, False), use_proportional_edit=False)
			bbox = get_BBOX_multi(multi_object_loop(getSelectionBBox, need_results=True))
			if bbox['minLength'] < bboxPrevious['minLength']:
				bboxPrevious = bbox
			else:
				bpy.ops.transform.rotate(value=(angle * math.pi / 180), orient_axis='Z', constraint_axis=(False, False, False), use_proportional_edit=False)
		angle /= 2