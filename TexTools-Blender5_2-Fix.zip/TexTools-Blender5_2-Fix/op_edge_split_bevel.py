import bpy
import bmesh
from mathutils import Vector

from . import utilities_uv


class op(bpy.types.Operator):
	bl_idname = "uv.textools_edge_split_bevel"
	bl_label = "Split Bevel"
	bl_description = "..."
	bl_options = {'REGISTER', 'UNDO'}

	radius : bpy.props.FloatProperty(
		name = "Space",
		description = "Space for split bevel",
		default = 0.015,
		min = 0,
		max = 0.35
	)

	@classmethod
	def poll(cls, context):
		if bpy.context.area.ui_type != 'UV':
			return False
		if not bpy.context.active_object:
			return False
		if bpy.context.active_object.mode != 'EDIT':
			return False
		if not bpy.context.object.data.uv_layers:
			return False
		if bpy.context.scene.tool_settings.use_uv_select_sync:
			return False
		return True


	def execute(self, context):
		main(self, self.radius)
		return {'FINISHED'}


def main(self, radius):
	bm = bmesh.from_edit_mesh(bpy.context.active_object.data)
	uv_layers = bm.loops.layers.uv.verify()
	
	selected_faces = utilities_uv.selection_store(bm, uv_layers, return_selected_UV_faces=True)
	islands = utilities_uv.getSelectionIslands(bm, uv_layers, selected_faces=selected_faces)

	vert_to_uv = utilities_uv.get_vert_to_uv(bm, uv_layers)

	edges = [edge for edge in bm.edges if edge.select and not edge.smooth]
	vert_rails = get_vert_edge_rails(edges)
	edge_face_pairs = get_edge_face_pairs(edges)

	vert_processed = []
	vert_uv_pos = []

	for edge in edges:
		if len(edge_face_pairs[edge]) == 2:
			v0, v1 = edge.verts[0], edge.verts[1]
			f0, f1 = edge_face_pairs[edge][0], edge_face_pairs[edge][1]

			if v0 not in vert_processed:
				vert_processed.append(v0)
				faces, origin, delta = slide_uvs(v0, edge, f0, edges, vert_rails, vert_to_uv)
				vert_uv_pos.append({"v": v0, "f": f0, "origin": origin, "delta": delta, "faces": faces})
				faces, origin, delta = slide_uvs(v0, edge, f1, edges, vert_rails, vert_to_uv)
				vert_uv_pos.append({"v": v0, "f": f1, "origin": origin, "delta": delta, "faces": faces})

			if v1 not in vert_processed:
				vert_processed.append(v1)
				faces, origin, delta = slide_uvs(v1, edge, f0, edges, vert_rails, vert_to_uv)
				vert_uv_pos.append({"v": v1, "f": f0, "origin": origin, "delta": delta, "faces": faces})
				faces, origin, delta = slide_uvs(v1, edge, f1, edges, vert_rails, vert_to_uv)
				vert_uv_pos.append({"v": v1, "f": f1, "origin": origin, "delta": delta, "faces": faces})
	
	for item in vert_uv_pos:
		v = item["v"]
		for face in item["faces"]:
			if v in face.verts:
				for loop in face.loops:
					if loop.vert == v:
						loop[uv_layers].uv = item["origin"] + item["delta"] * (radius / 2)

	utilities_uv.selection_restore(bm, uv_layers)


def slide_uvs(vert, edge, face, edges, vert_rails, vert_to_uv):
	A, B = edge.verts[0], edge.verts[1]
	A_links, B_links = get_edge_prev_next(edge, edges)
	
	verts_edges = {edge.verts[0], edge.verts[1]}
	verts_edges.update(A_links)
	verts_edges.update(B_links)

	faces = [face]
	edges_main_used = [edge]
	for i in range(2):
		append = []
		for f in faces:
			for e in f.edges:
				if e not in edges_main_used:
					if e in edges:
						edges_main_used.append(e)
					for f_link in e.link_faces:
						if f_link not in faces:
							append.append(f_link)
		faces.extend(append)

	face_edges = list(set([e for f in faces for e in f.edges if e not in edges]))
	verts = [A, B]
	if vert == A:
		verts.extend(B_links)
	elif vert == B:
		verts.extend(A_links)

	delta = Vector((0, 0))
	count = 0.0
	for v in verts:
		rails = [e for e in vert_rails.get(v, []) if e in face_edges]
		for e in rails:
			v0 = e.verts[0] if e.verts[0] in verts_edges else e.verts[1]
			v1 = e.verts[1] if e.verts[0] in verts_edges else e.verts[0]
			uv0 = vert_to_uv[v0][0].uv
			uv1 = vert_to_uv[v1][0].uv
			delta += (uv1 - uv0).normalized()
			count += 1.0

	if count > 0:
		delta /= count

	return faces, vert_to_uv[vert][0].uv.copy(), delta.normalized()


def get_edge_prev_next(edge, edges):
	A, B = edge.verts[0], edge.verts[1]
	A_extends = [v2 for v1 in edge.verts for e in v1.link_edges for v2 in e.verts if e != edge and e in edges and v2 not in edge.verts and v1 != A]
	B_extends = [v2 for v1 in edge.verts for e in v1.link_edges for v2 in e.verts if e != edge and e in edges and v2 not in edge.verts and v1 != B]
	return A_extends, B_extends


def get_edge_face_pairs(edges):
	edge_faces = {}
	for edge in edges:
		v0, v1 = edge.verts[0], edge.verts[1]
		edge_faces[edge] = [face for face in edge.link_faces if v0 in face.verts and v1 in face.verts]
	return edge_faces


def get_vert_edge_rails(edges):
	vert_rails = {}
	for edge in edges:
		v0, v1 = edge.verts[0], edge.verts[1]
		faces = [face for face in edge.link_faces if v0 in face.verts and v1 in face.verts]
		for face in faces:
			for e in face.edges:
				if e not in edges and len(e.link_faces) > 0:
					if v0 not in vert_rails: vert_rails[v0] = []
					if v1 not in vert_rails: vert_rails[v1] = []
					if v0 in e.verts and e not in vert_rails[v0]: vert_rails[v0].append(e)
					if v1 in e.verts and e not in vert_rails[v1]: vert_rails[v1].append(e)
	return vert_rails


bpy.utils.register_class(op)