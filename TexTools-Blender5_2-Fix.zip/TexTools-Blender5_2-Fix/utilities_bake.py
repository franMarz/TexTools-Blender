import bpy
import bmesh
from mathutils import Vector
from math import pi

from . import utilities_color
from . import settings

keywords_low = ['lowpoly', 'low', 'lowp', 'lp', 'lo']
keywords_high = ['highpoly', 'high', 'highp', 'hp', 'hi']
keywords_cage = ['cage']
keywords_float = ['floater', 'float']
split_chars = [' ', '_', '.', '-']

if settings.bversion >= 4.0:
	chs = {'ech': 26, 'rch': 2, 'trch': 2, 'ssch': 7, 'scch': 0, 'mch': 1, 'sch': 12, 'stch': 13, 'ach': 14, 'arch': 15, 'shch': 23, 'shtch': 25, 'cch': 18, 'crch': 19, 'esch': 27, 'alch': 4}
else:
	sh = 2 if settings.bversion >= 3.0 else 0
	chs = {'ech': 17+sh, 'rch': 7+sh, 'ssch': 1, 'scch': 3, 'mch': 4+sh, 'sch': 5+sh, 'stch': 0, 'shtch': 0, 'ach': 8+sh, 'arch': 9+sh, 'shch': 10+sh, 'cch': 12+sh, 'crch': 13+sh, 'trch': 16+sh, 'esch': 18+sh, 'alch': 19+sh}

allMaterials = []
allMaterialsNames = []
elementsCount = 0


class BakeMode:
	material = ""
	type = 'EMIT'
	normal_space = 'TANGENT'
	setVColor = None
	color = (0.23, 0.23, 0.23, 1)
	engine = 'CYCLES'
	composite = None
	use_project = False
	invert = False
	relink = {'needed': False}
	params = []

	def __init__(self, material="", type='EMIT', normal_space='TANGENT', setVColor=None, color=(0.23, 0.23, 0.23, 1), engine='CYCLES', params=[], composite=None, use_project=False, invert=False, relink={'needed': False}):
		self.material = material
		self.type = type
		self.normal_space = normal_space
		self.setVColor = setVColor
		self.color = color
		self.engine = engine
		self.params = params
		self.composite = composite
		self.use_project = use_project
		self.invert = invert
		self.relink = relink


def on_select_bake_mode(mode):
	if len(settings.sets) > 0:
		name_texture = f"{settings.sets[0].name}_{mode}"
		if name_texture in bpy.data.images:
			image = bpy.data.images[name_texture]
			for area in bpy.context.screen.areas:
				if area.ui_type == 'UV':
					area.spaces[0].image = image


def store_bake_settings():
	settings.bake_render_engine = bpy.context.scene.render.engine
	settings.bake_cycles_device = bpy.context.scene.cycles.device
	settings.bake_cycles_samples = bpy.context.scene.cycles.samples
	if settings.bversion >= 2.92:
		settings.bake_target_mode = bpy.context.scene.render.bake.target
	if settings.bversion < 3:
		settings.use_progressive_refine = bpy.context.scene.cycles.use_progressive_refine
	if settings.bversion >= 3:
		settings.use_denoising = bpy.context.scene.cycles.use_denoising
	settings.bake_objects_hide_render = []


def restore_bake_settings():
	if settings.bake_render_engine != '':
		bpy.context.scene.render.engine = settings.bake_render_engine
	bpy.context.scene.cycles.device = settings.bake_cycles_device
	bpy.context.scene.cycles.samples = settings.bake_cycles_samples
	if settings.bversion >= 2.92:
		bpy.context.scene.render.bake.target = settings.bake_target_mode
	if settings.bversion < 3:
		bpy.context.scene.cycles.use_progressive_refine = settings.use_progressive_refine
	if settings.bversion >= 3:
		bpy.context.scene.cycles.use_denoising = settings.use_denoising

	for obj in settings.bake_objects_hide_render:
		if obj:
			obj.hide_render = False


def get_set_name_base(obj):
	def remove_digits(name):
		if len(name) > 4 and name[-4] == '.' and name[-3:].isdigit():
			return name[:-4]
		return name

	if obj.parent and obj.parent in bpy.context.selected_objects:
		return remove_digits(obj.parent.name).lower()
	elif len(obj.users_collection) == 2:
		return remove_digits(obj.users_collection[0].name).lower()
	else:
		return remove_digits(obj.name).lower()


def get_set_name(obj):
	if bpy.context.scene.texToolsSettings.bake_force == "Multi":
		return obj.name

	name = get_set_name_base(obj)
	split = name.lower()
	for char in split_chars:
		split = split.replace(char, ' ')
	strings = split.split(' ')

	keys = keywords_cage + keywords_high + keywords_low + keywords_float
	new_strings = []
	for string in strings:
		if string in keys:
			if len(new_strings) > 0: break
		else:
			new_strings.append(string)

	return "_".join(new_strings)


def get_object_type(obj):
	if bpy.context.scene.texToolsSettings.bake_force == "Multi":
		return 'low'

	name = get_set_name_base(obj)
	split = name.lower()
	for char in split_chars:
		split = split.replace(char, ' ')
	strings = split.split(' ')

	for string in strings:
		if string in keywords_float: return 'float'

	if bpy.context.preferences.addons[__package__].preferences.bool_modifier_auto_high and len(bpy.context.selected_objects) > 1:
		if obj.modifiers:
			for modifier in obj.modifiers:
				if (modifier.type == 'SUBSURF' and modifier.render_levels > 0) or modifier.type == 'BEVEL':
					return 'high'

	for string in strings:
		if string in keywords_high: return 'high'
	for string in strings:
		if string in keywords_cage: return 'cage'
	for string in strings:
		if string in keywords_low: return 'low'
	return 'low'


def get_baked_images(sets):
	images = []
	for bset in sets:
		name_texture = f"{bset.name}_"
		for image in bpy.data.images:
			if name_texture in image.name:
				images.append(image)
	return images


def get_bake_sets():
	filtered = {}
	if len(bpy.context.selected_objects) == 0:
		if bpy.context.active_object and bpy.context.active_object.mode == 'EDIT' and bpy.context.active_object.type == 'MESH':
			filtered[bpy.context.active_object] = get_object_type(bpy.context.active_object)
	else:
		for obj in bpy.context.selected_objects:
			if obj.type == 'MESH':
				filtered[obj] = get_object_type(obj)

	groups = []
	for obj in filtered:
		name = get_set_name(obj)
		if not groups:
			groups.append([obj])
		else:
			isFound = False
			for group in groups:
				if name == get_set_name(group[0]):
					group.append(obj)
					isFound = True
					break
			if not isFound: groups.append([obj])

	keys = [get_set_name(group[0]) for group in groups]
	keys.sort()
	sorted_groups = [group for key in keys for group in groups if key == get_set_name(group[0])]

	bake_sets = []
	for group in sorted_groups:
		low, cage, high, float_objs = [], [], [], []
		for obj in group:
			t = filtered[obj]
			if t == 'low': low.append(obj)
			elif t == 'high': high.append(obj)
			elif t == 'cage': cage.append(obj)
			elif t == 'float': float_objs.append(obj)

		bake_sets.append(BakeSet(get_set_name(group[0]), low, cage, high, float_objs))
	return bake_sets


class BakeSet:
	objects_low = []
	objects_cage = []
	objects_high = []
	objects_float = []
	name = ""
	has_issues = False

	def __init__(self, name, objects_low, objects_cage, objects_high, objects_float):
		self.objects_low = objects_low
		self.objects_cage = objects_cage
		self.objects_high = objects_high
		self.objects_float = objects_float
		self.name = name

		if len(objects_low) == 0 or (len(objects_cage) > 0 and len(objects_low) != len(objects_cage)):
			self.has_issues = True
		for obj in objects_low:
			if len(obj.data.uv_layers) == 0:
				self.has_issues = True
				break


def assign_vertex_color(obj):
	vclsNames = [vcl.name for vcl in obj.data.vertex_colors]
	if 'TexTools_temp' in vclsNames:
		obj.data.vertex_colors['TexTools_temp'].active = True
		obj.data.vertex_colors['TexTools_temp'].active_render = True
	else:
		obj.data.vertex_colors.new(name='TexTools_temp')
		obj.data.vertex_colors['TexTools_temp'].active = True
		obj.data.vertex_colors['TexTools_temp'].active_render = True


def setup_vertex_color_selection(obj):
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(state=True)
	bpy.context.view_layer.objects.active = obj
	bpy.ops.object.mode_set(mode='VERTEX_PAINT')
	bpy.context.tool_settings.vertex_paint.brush.color = (0, 0, 0)
	bpy.context.object.data.use_paint_mask = False
	bpy.ops.paint.vertex_color_set()
	bpy.context.tool_settings.vertex_paint.brush.color = (1, 1, 1)
	bpy.context.object.data.use_paint_mask = True
	bpy.ops.paint.vertex_color_set()
	bpy.context.object.data.use_paint_mask = False
	bpy.ops.object.mode_set(mode='OBJECT')


def setup_vertex_color_dirty(obj):
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(state=True)
	bpy.context.view_layer.objects.active = obj
	bpy.ops.object.mode_set(mode='EDIT')

	bm = bmesh.from_edit_mesh(obj.data)
	colorLayer = (obj.data.attributes.active_color_index if settings.bversion >= 3.4 else bm.loops.layers.color.active)
	color = utilities_color.safe_color((1, 1, 1))

	for face in bm.faces:
		for loop in face.loops:
			if settings.bversion >= 3.4:
				loop[bm.loops.layers.color[colorLayer]] = color
			else:
				loop[colorLayer] = color

	obj.data.update()
	bpy.ops.object.mode_set(mode='OBJECT')
	bpy.ops.paint.vertex_color_dirt(dirt_angle=pi/2)
	bpy.ops.paint.vertex_color_dirt()


def setup_vertex_color_id_material(obj, previous_materials):
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(state=True)
	bpy.context.view_layer.objects.active = obj
	bpy.ops.object.mode_set(mode='EDIT')
	bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')

	for i, mtlname in enumerate(previous_materials[obj]):
		if mtlname is not None:
			bpy.ops.object.mode_set(mode='EDIT')
			bpy.ops.mesh.select_all(action='DESELECT')
			bm = bmesh.from_edit_mesh(bpy.context.active_object.data)
			for face in bm.faces:
				if face.material_index == i: face.select = True
			
			color = utilities_color.get_color_id(allMaterials.index(bpy.data.materials[mtlname]), 256, jitter=True)
			bpy.ops.object.mode_set(mode='VERTEX_PAINT')
			bpy.context.tool_settings.vertex_paint.brush.color = color
			bpy.context.object.data.use_paint_mask = True
			bpy.ops.paint.vertex_color_set()

	obj.data.update()
	bpy.ops.object.mode_set(mode='OBJECT')


def setup_vertex_color_id_element(obj):
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(state=True)
	bpy.context.view_layer.objects.active = obj
	bpy.ops.object.mode_set(mode='EDIT')
	bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')

	bm = bmesh.from_edit_mesh(obj.data)
	colorLayer = (bm.loops.layers.color[obj.data.attributes.active_color_index] if settings.bversion >= 3.4 else bm.loops.layers.color.active)

	processed, groups = set(), []
	for face in bm.faces:
		if face not in processed:
			bpy.ops.mesh.select_all(action='DESELECT')
			face.select = True
			bpy.ops.mesh.select_linked(delimit={'NORMAL'})
			linked = [f for f in bm.faces if f.select]
			processed.update(linked)
			groups.append(linked)

	global elementsCount
	for i in range(len(groups)):
		color = utilities_color.safe_color(utilities_color.get_color_id(elementsCount + i, 256, jitter=True))
		for face in groups[i]:
			for loop in face.loops:
				loop[colorLayer] = color

	elementsCount += len(groups)
	obj.data.update()
	bpy.ops.object.mode_set(mode='OBJECT')


def get_image_material(image):
	material = bpy.data.materials.get(image.name)
	if material:
		bpy.data.materials.remove(material, do_unlink=True)
	material = bpy.data.materials.new(image.name)

	if bpy.context.scene.render.engine in {'CYCLES', 'BLENDER_EEVEE'}:
		material.use_nodes = True
		node_image = material.node_tree.nodes.get("image") or material.node_tree.nodes.new("ShaderNodeTexImage")
		node_image.name = "image"
		node_image.select = True
		node_image.image = image
		material.node_tree.nodes.active = node_image

		bsdf_node = next((n for n in material.node_tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)

		if "_normal_" in image.name:
			node_normal_map = material.node_tree.nodes.get("normal_map") or material.node_tree.nodes.new("ShaderNodeNormalMap")
			node_normal_map.name = "normal_map"
			node_normal_map.space = 'TANGENT' if image.name.endswith("normal_tangent") else 'WORLD'

			material.node_tree.links.new(node_image.outputs[0], node_normal_map.inputs[1])
			material.node_tree.links.new(node_normal_map.outputs[0], bsdf_node.inputs[19 if settings.bversion < 2.91 else 20])
			node_normal_map.location = bsdf_node.location - Vector((200, 0))
			node_image.location = node_normal_map.location - Vector((200, 0))
		else:
			material.node_tree.links.new(node_image.outputs[0], bsdf_node.inputs[0])

		return material