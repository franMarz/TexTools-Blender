import bpy

from . import utilities_ui
from . import utilities_uv


class op(bpy.types.Operator):
	bl_idname = "uv.textools_uv_channel_add"
	bl_label = "Add UV Channel"
	bl_description = "Add a new UV channel to all the selected Objects"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		if not bpy.context.active_object or bpy.context.active_object.type != 'MESH':
			return False
		return True


	def execute(self, context):
		premode = bpy.context.active_object.mode
		utilities_uv.multi_object_loop(adduvs, self, context)
		bpy.ops.object.mode_set(mode=premode)
		return {'FINISHED'}


def adduvs(self, context):
	obj = bpy.context.active_object
	if len(obj.data.uv_layers) == 0:
		obj.data.uv_layers.new(name="UVMap")
	else:
		name = f"UVMap{len(obj.data.uv_layers) + 1}"
		obj.data.uv_layers.new(name=name)

	index = len(obj.data.uv_layers) - 1
	obj.data.uv_layers.active_index = index
	bpy.context.scene.texToolsSettings.uv_channel = str(index)
	obj.data.uv_layers[0].active_render = True


bpy.utils.register_class(op)