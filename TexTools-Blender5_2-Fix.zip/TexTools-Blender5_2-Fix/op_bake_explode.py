import bpy
import operator
from mathutils import Vector

from . import settings

frame_range = 50


class op(bpy.types.Operator):
	bl_idname = "uv.textools_bake_explode"
	bl_label = "Explode"
	bl_description = "Explode selected bake pairs with animation keyframes"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		return len(settings.sets) > 1

	def execute(self, context):
		explode(self)
		return {'FINISHED'}


def explode(self):
	sets = settings.sets
	set_bounds = {}
	set_volume = {}
	avg_side = 0

	for bset in sets:
		set_bounds[bset] = get_bbox_set(bset)
		size = set_bounds[bset]['size']
		set_volume[bset] = size.x * size.y * size.z
		avg_side += size.x + size.y + size.z

	avg_side /= (len(sets) * 3)

	sorted_set_volume = sorted(set_volume.items(), key=operator.itemgetter(1), reverse=True)
	sorted_sets = [item[0] for item in sorted_set_volume]

	bbox_all = merge_bounds(list(set_bounds.values()))
	bbox_max = set_bounds[sorted_sets[0]]

	dir_offset_last_bbox = {i: bbox_max for i in range(6)}

	bpy.context.scene.frame_start = 0
	bpy.context.scene.frame_end = frame_range
	bpy.context.scene.frame_current = 0

	for bset in sorted_sets[1:]:
		delta = set_bounds[bset]['center'] - bbox_all['center']
		offset_set(bset, delta, avg_side * 0.35, dir_offset_last_bbox)

	bpy.context.scene.frame_current = frame_range


def offset_set(bset, delta, margin, dir_offset_last_bbox):
	objects = bset.objects_low + bset.objects_high + bset.objects_cage

	delta_max = max(abs(delta.x), abs(delta.y), abs(delta.z))
	direction = [0, 0, 0]
	if delta_max > 0:
		for i in range(3):
			if abs(delta[i]) == delta_max:
				direction[i] = delta[i] / abs(delta[i])
				break
	else:
		direction = [0, 0, 1]

	v_dir = Vector(direction)
	key = get_delta_key(v_dir)

	bbox = get_bbox_set(bset)
	bbox_last = dir_offset_last_bbox[key]
	offset = Vector((0, 0, 0))

	if v_dir.x == 1:
		offset = v_dir * (bbox_last['max'].x - bbox['min'].x)
	elif v_dir.x == -1:
		offset = v_dir * -(bbox_last['min'].x - bbox['max'].x)
	elif v_dir.y == 1:
		offset = v_dir * (bbox_last['max'].y - bbox['min'].y)
	elif v_dir.y == -1:
		offset = v_dir * -(bbox_last['min'].y - bbox['max'].y)
	elif v_dir.z == 1:
		offset = v_dir * (bbox_last['max'].z - bbox['min'].z)
	elif v_dir.z == -1:
		offset = v_dir * -(bbox_last['min'].z - bbox['max'].z)

	offset += v_dir * margin

	for obj in objects:
		bpy.context.view_layer.update()
		obj.keyframe_insert(data_path="location", frame=0)
		obj.location += offset
		bpy.context.view_layer.update()
		obj.keyframe_insert(data_path="location", frame=frame_range)

	dir_offset_last_bbox[key] = get_bbox_set(bset)


def get_delta_key(delta):
	if delta.x == -1: return 0
	if delta.x == 1: return 1
	if delta.y == -1: return 2
	if delta.y == 1: return 3
	if delta.z == -1: return 4
	return 5


def merge_bounds(bounds):
	box_min = bounds[0]['min'].copy()
	box_max = bounds[0]['max'].copy()

	for bbox in bounds:
		box_min.x = min(box_min.x, bbox['min'].x)
		box_min.y = min(box_min.y, bbox['min'].y)
		box_min.z = min(box_min.z, bbox['min'].z)
		box_max.x = max(box_max.x, bbox['max'].x)
		box_max.y = max(box_max.y, bbox['max'].y)
		box_max.z = max(box_max.z, bbox['max'].z)

	return {
		'min': box_min, 
		'max': box_max, 
		'size': (box_max - box_min),
		'center': box_min + (box_max - box_min) / 2
	}


def get_bbox_set(bset):
	objects = bset.objects_low + bset.objects_high + bset.objects_cage
	return merge_bounds([get_bbox(obj) for obj in objects])


def get_bbox(obj):
	corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
	box_min = corners.copy()[0]
	box_max = corners.copy()[0]

	for corner in corners:
		box_min.x = min(box_min.x, corner.x)
		box_min.y = min(box_min.y, corner.y)
		box_min.z = min(box_min.z, corner.z)
		box_max.x = max(box_max.x, corner.x)
		box_max.y = max(box_max.y, corner.y)
		box_max.z = max(box_max.z, corner.z)

	return {
		'min': box_min, 
		'max': box_max, 
		'size': (box_max - box_min),
		'center': box_min + (box_max - box_min) / 2
	}


bpy.utils.register_class(op)