import bpy
import bmesh

from math import hypot
from collections import defaultdict
from . import utilities_uv

precision = 3


class op(bpy.types.Operator):
	bl_idname = "uv.textools_rectify"
	bl_label = "Rectify"
	bl_description = "Align selected UV faces or vertices to rectangular distribution"
	bl_options = {'REGISTER', 'UNDO'}

	@classmethod
	def poll(cls, context):
		if bpy.context.area.ui_type != 'UV': return False
		if not bpy.context.active_object or bpy.context.active_object.mode != 'EDIT': return False
		if bpy.context.active_object.type != 'MESH' or not bpy.context.active_object.data.uv_layers: return False
		if context.scene.tool_settings.use_uv_select_sync: return False
		return True


	def execute(self, context):
		utilities_uv.multi_object_loop(rectify, self, context)
		return {'FINISHED'}


def rectify(self, context, me=None, bm=None, uv_layers=None):
	if me is None:
		me = bpy.context.active_object.data
		bm = bmesh.from_edit_mesh(me)
		uv_layers = bm.loops.layers.uv.verify()

	faces_loops = utilities_uv.selection_store(bm, uv_layers, return_selected_faces_loops=True)
	islands = utilities_uv.getSelectionIslands(bm, uv_layers, selected_faces=set(faces_loops.keys()))

	for island in islands:
		bpy.ops.uv.select_all(action='DESELECT')
		utilities_uv.set_selected_faces(island, bm, uv_layers)
		main(me, bm, uv_layers, island, faces_loops)
	
	utilities_uv.selection_restore(bm, uv_layers)


def main(me, bm, uv_layers, selFacesMix, faces_loops, return_discarded_faces=False):
	filteredVerts, selFaces, vertsDict, discarded_faces = ListsOfVerts(bm, uv_layers, selFacesMix, faces_loops)   

	if len(filteredVerts) < 2:
		return set() if return_discarded_faces else None

	if not selFaces:
		if discarded_faces and return_discarded_faces:
			return discarded_faces
		else:
			for luv in filteredVerts:
				x, y = round(luv.uv.x, precision), round(luv.uv.y, precision)
				if luv not in vertsDict[(x, y)]:
					vertsDict[(x, y)].append(luv)

			areLinedX = areLinedY = True
			allowedError = 0.00001
			valX, valY = filteredVerts[0].uv.x, filteredVerts[0].uv.y
			for v in filteredVerts:
				if abs(valX - v.uv.x) > allowedError: areLinedX = False
				if abs(valY - v.uv.y) > allowedError: areLinedY = False
			
			if not (areLinedX or areLinedY):
				filteredVerts.sort(key=lambda x: x.uv[0])
				first, last = filteredVerts[0], filteredVerts[-1]
				horizontal = True
				if (last.uv.x - first.uv.x) > 0.0009:
					slope = (last.uv.y - first.uv.y) / (last.uv.x - first.uv.x)
					if abs(slope) > 1: horizontal = False
				else:
					horizontal = False
				
				if horizontal:
					for v in filteredVerts:
						for luv in vertsDict[(round(v.uv.x, precision), round(v.uv.y, precision))]:
							luv.uv.y = first.uv.y
				else:
					filteredVerts.sort(key=lambda x: x.uv[1], reverse=True)
					first = filteredVerts[0]
					for v in filteredVerts:
						for luv in vertsDict[(round(v.uv.x, precision), round(v.uv.y, precision))]:
							luv.uv.x = first.uv.x
	else:
		targetFace = bm.faces.active
		if targetFace is None or len({loop for loop in targetFace.loops}.intersection(filteredVerts)) != len(targetFace.verts) or not targetFace.select or len(targetFace.verts) != 4:
			targetFace = selFaces[0]
		
		ShapeFace(uv_layers, targetFace, vertsDict)
		FollowActiveUV(me, targetFace, selFaces)
		bmesh.update_edit_mesh(me, loop_triangles=False)
		if return_discarded_faces:
			return discarded_faces


def ListsOfVerts(bm, uv_layers, selFacesMix, faces_loops):
	allEdgeVerts = []
	filteredVerts = []
	selFaces = []
	discarded_faces = set()
	vertsDict = defaultdict(list)
	
	for f in selFacesMix:
		isFaceSel = len(faces_loops[f]) == len(f.loops)
		facesEdgeVerts = [l[uv_layers] for l in faces_loops[f]]
		allEdgeVerts.extend(facesEdgeVerts)
		if isFaceSel:
			if len(f.verts) != 4:
				filteredVerts.extend(facesEdgeVerts)
				discarded_faces.add(f)
			else: 
				selFaces.append(f)
				for luv in facesEdgeVerts:
					vertsDict[(round(luv.uv.x, precision), round(luv.uv.y, precision))].append(luv)
		else:
			filteredVerts.extend(facesEdgeVerts)

	if len(filteredVerts) == 0:
		filteredVerts.extend(allEdgeVerts)

	return filteredVerts, selFaces, vertsDict, discarded_faces


def ShapeFace(uv_layers, targetFace, vertsDict):
	corners = [l[uv_layers] for l in targetFace.loops]
	if len(corners) != 4:
		return
	
	firstHighest = max(corners, key=lambda c: c.uv.y)
	corners.remove(firstHighest)
	secondHighest = max(corners, key=lambda c: c.uv.y)
	
	leftUp, rightUp = (firstHighest, secondHighest) if firstHighest.uv.x < secondHighest.uv.x else (secondHighest, firstHighest)
	corners.remove(secondHighest)
	
	leftDown, rightDown = (corners[0], corners[1]) if corners[0].uv.x < corners[1].uv.x else (corners[1], corners[0])
	verts = [leftUp, leftDown, rightDown, rightUp]

	ratioX, ratioY = ImageRatio()
	min_val, minV = float('inf'), verts[0]
	for v in verts:
		if v is None: continue
		for area in bpy.context.screen.areas:
			if area.ui_type == 'UV':
				loc = area.spaces[0].cursor_location
				hyp = hypot(loc.x / ratioX - v.uv.x, loc.y / ratioY - v.uv.y)
				if hyp < min_val:
					min_val, minV = hyp, v

	MakeUvFaceEqualRectangle(vertsDict, leftUp, rightUp, rightDown, leftDown, minV)


def MakeUvFaceEqualRectangle(vertsDict, leftUp, rightUp, rightDown, leftDown, startv):
	if startv is None or AreVertsQuasiEqual(startv, leftUp): startv = leftUp.uv
	elif AreVertsQuasiEqual(startv, rightUp): startv = rightUp.uv
	elif AreVertsQuasiEqual(startv, rightDown): startv = rightDown.uv
	elif AreVertsQuasiEqual(startv, leftDown): startv = leftDown.uv
	else: startv = leftUp.uv
	
	leftUp, rightUp, rightDown, leftDown = leftUp.uv, rightUp.uv, rightDown.uv, leftDown.uv    
   
	if startv == leftUp: 
		finalScaleX, finalScaleY = hypotVert(leftUp, rightUp), hypotVert(leftUp, leftDown)
		currRowX, currRowY = leftUp.x, leftUp.y
	elif startv == rightUp:
		finalScaleX, finalScaleY = hypotVert(rightUp, leftUp), hypotVert(rightUp, rightDown)
		currRowX, currRowY = rightUp.x - finalScaleX, rightUp.y
	elif startv == rightDown:
		finalScaleX, finalScaleY = hypotVert(rightDown, leftDown), hypotVert(rightDown, rightUp)
		currRowX, currRowY = rightDown.x - finalScaleX, rightDown.y + finalScaleY
	else:
		finalScaleX, finalScaleY = hypotVert(leftDown, rightDown), hypotVert(leftDown, leftUp)
		currRowX, currRowY = leftDown.x, leftDown.y + finalScaleY
	
	for v in vertsDict[(round(leftUp.x, precision), round(leftUp.y, precision))]:
		v.uv.x, v.uv.y = currRowX, currRowY
	for v in vertsDict[(round(rightUp.x, precision), round(rightUp.y, precision))]:
		v.uv.x, v.uv.y = currRowX + finalScaleX, currRowY
	for v in vertsDict[(round(rightDown.x, precision), round(rightDown.y, precision))]:
		v.uv.x, v.uv.y = currRowX + finalScaleX, currRowY - finalScaleY
	for v in vertsDict[(round(leftDown.x, precision), round(leftDown.y, precision))]:
		v.uv.x, v.uv.y = currRowX, currRowY - finalScaleY


def FollowActiveUV(me, f_act, faces):
	bm = bmesh.from_edit_mesh(me)
	uv_act = bm.loops.layers.uv.active
	
	def walk_face_init(faces, f_act):
		for f in bm.faces: f.tag = True
		for f in faces: f.tag = False
		f_act.tag = True

	def walk_face(f):
		f.tag = True
		faces_a, faces_b = [f], []
		while faces_a:
			for fa in faces_a:
				for l in fa.loops:
					if l.edge.is_manifold and not l.edge.seam:
						f_other = l.link_loop_radial_next.face
						if not f_other.tag:
							yield (fa, l, f_other)
							f_other.tag = True
							faces_b.append(f_other)
			faces_a, faces_b = faces_b, faces_a
			faces_b.clear()

	def walk_edgeloop(l):
		e_first = l.edge
		while True:
			e = l.edge
			yield e
			if e.is_manifold:
				l = l.link_loop_radial_next
				if len(l.face.verts) == 4:
					l = l.link_loop_next.link_loop_next
					if l.edge is e_first: break
				else: break
			else: break

	def extrapolate_uv(fac, l_a_outer, l_a_inner, l_b_outer, l_b_inner):
		l_b_inner[:] = l_a_inner
		l_b_outer[:] = l_a_inner + ((l_a_inner - l_a_outer) * fac)

	def apply_uv(f_prev, l_prev, f_next):
		l_a = [l_prev, l_prev.link_loop_next, l_prev.link_loop_next.link_loop_next, l_prev.link_loop_next.link_loop_next.link_loop_next]
		l_next = l_prev.link_loop_radial_next
		l_b = [l_next, l_next.link_loop_next, l_next.link_loop_next.link_loop_next, l_next.link_loop_next.link_loop_next.link_loop_next] if l_next.vert == l_prev.vert else [l_next.link_loop_next, l_next, l_next.link_loop_next.link_loop_next.link_loop_next, l_next.link_loop_next.link_loop_next]

		l_a_uv, l_b_uv = [l[uv_act].uv for l in l_a], [l[uv_act].uv for l in l_b]
		try: fac = edge_lengths[l_b[2].edge.index][0] / edge_lengths[l_a[1].edge.index][0]
		except ZeroDivisionError: fac = 1.0

		extrapolate_uv(fac, l_a_uv[3], l_a_uv[0], l_b_uv[3], l_b_uv[0])
		extrapolate_uv(fac, l_a_uv[2], l_a_uv[1], l_b_uv[2], l_b_uv[1])

	bm.edges.index_update()
	edge_lengths = [None] * len(bm.edges)
	for f in faces:
		for l_pair in ((f.loops[0], f.loops[2]), (f.loops[1], f.loops[3])):
			if edge_lengths[l_pair[0].edge.index] is None:
				edge_length_store, edge_length_accum, edge_length_total = [-1.0], 0.0, 0
				for l in l_pair:
					if edge_lengths[l.edge.index] is None:
						for e in walk_edgeloop(l):
							if edge_lengths[e.index] is None:
								edge_lengths[e.index] = edge_length_store
								edge_length_accum += e.calc_length()
								edge_length_total += 1
				edge_length_store[0] = edge_length_accum / edge_length_total

	walk_face_init(faces, f_act)
	for f_triple in walk_face(f_act):
		apply_uv(*f_triple)


def ImageRatio():
	ratioX, ratioY = 256, 256
	for a in bpy.context.screen.areas:
		if a.type == 'IMAGE_EDITOR':
			img = a.spaces[0].image
			if img and img.size[0] != 0:
				ratioX, ratioY = img.size[0], img.size[1]
			break
	return ratioX, ratioY


def AreVertsQuasiEqual(v1, v2, allowedError=0.00001):
	return abs(v1.uv.x - v2.uv.x) < allowedError and abs(v1.uv.y - v2.uv.y) < allowedError


def hypotVert(v1, v2):
	return hypot(v1.x - v2.x, v1.y - v2.y)


bpy.utils.register_class(op)